# Toxic Gas
### Adds toxic gas and gasmask item.

![](https://i.imgur.com/G9RUG3d.jpg)

### Models are from [HL2 RP Essential Faction Models](https://steamcommunity.com/sharedfiles/filedetails/?id=636614821) on the workshop.
#### You can change the item models and the pac outfit to whatever you want though.

## Usage

#### Commands
##### `/AddToxicGas` adds a toxic gas box from where you are standing to where you are looking (box min to max)
##### `/RemoveToxicGas` removes the toxic gas box you're closest to.

#### Console Variables
##### `ix_toxicgas_observer` (`1|0`) toggles showing toxic gas boxes when in observer/noclip.
