ITEM.name = "Advanced Gasmask"
ITEM.model = Model("models/devcon/mrp/props/gasmask_stalker.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "A post-war multi-filter gasmask, handy for going topside."
maskItem = true