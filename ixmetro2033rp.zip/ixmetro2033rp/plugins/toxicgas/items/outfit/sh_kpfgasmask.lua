ITEM.name = "KPF Gasmask"
ITEM.model = Model("models/maver1k_xvii/metro_digger_helmet.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "A heavy-duty gasmask, intended for use with combat armour. A K with a circle is engraved into the sides of the helmet,."