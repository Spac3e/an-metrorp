ITEM.name = "Basic Gasmask"
ITEM.model = Model("models/half-dead/metrollfix/p_mask_2.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "A relatively basic gasmask with a glass visor & single filter system."
ITEM.chance = 51
maskItem = true