ITEM.name = "Gasmask Filter"
ITEM.model = Model("models/teebeutel/metro/objects/gasmask_filter.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "An air filter meant to be attached to a gasmask"
