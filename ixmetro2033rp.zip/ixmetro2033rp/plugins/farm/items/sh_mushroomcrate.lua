ITEM.name = "Mushroom Crate"
ITEM.description = "A crate of tightly packed with mushrooms."
ITEM.model = "models/devcon/mrp/props/weapon_shipment.mdl"
ITEM.uniqueID = "mushroom_crate"

ITEM.width = 2
ITEM.height = 1

ITEM.price = 30
