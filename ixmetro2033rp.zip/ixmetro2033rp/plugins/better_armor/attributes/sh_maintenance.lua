
-- You can define attributes in the attributes/ folder. The unique ID of the attribute will be the same as the name of the file.

ATTRIBUTE.name = "Maintenance"
ATTRIBUTE.description = "Your ability to repair armors."