You need this addons to see the gasmask overlay :

https://steamcommunity.com/sharedfiles/filedetails/?id=641535324

/gasmask to unwear/wear the gasmask
