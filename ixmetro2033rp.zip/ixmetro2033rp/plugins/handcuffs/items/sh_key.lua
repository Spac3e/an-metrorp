
ITEM.name = "Key for handcuffs"
ITEM.model = Model("models/mosi/fallout4/props/junk/tritool.mdl")
ITEM.description = "Key for open a handcuffs"
ITEM.category = "Miscellaneous"
ITEM.width = 1
ITEM.height = 1
ITEM.chance = 42
ITEM.rare = true
