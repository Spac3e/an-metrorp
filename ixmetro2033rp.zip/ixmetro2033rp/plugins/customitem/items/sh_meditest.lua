ITEM.name = "Optican Advanced Medical Response Kit"
ITEM.model = Model("models/ishi/halo_rebirth/props/human/health_kit.mdl")
ITEM.description = "An advanced medical kit used by field medics"
ITEM.category = "Medical"
ITEM.price = 0
ITEM.healthPoint = 90 -- Health point that the player will get
ITEM.medAttr = 50 -- How much medical attribute the character needs
ITEM.noBusiness = true