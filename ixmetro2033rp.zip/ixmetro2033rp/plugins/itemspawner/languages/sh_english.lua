LANGUAGE = {
	cmdItemSpawnerAdd    = "Add a new item spawnpoint.",
	cmdItemSpawnerRemove = "Removes an existant spawnpoint.",
	cmdItemSpawnerList   = "Displays a list of spawnpoints.",
	cmdNoSpawnPoints     = "There are no active spawnpoints.",
	cmdRemoved           = "The spawnpoint has been removed.",
	cmdNoRemoved         = "No spawnpoint with that name."
}
