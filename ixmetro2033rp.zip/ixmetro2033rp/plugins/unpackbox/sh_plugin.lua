PLUGIN.name = "BoxUnpack"
PLUGIN.description = "Boxes that contains unpackable entities."
PLUGIN.author = "Lechu2375"

