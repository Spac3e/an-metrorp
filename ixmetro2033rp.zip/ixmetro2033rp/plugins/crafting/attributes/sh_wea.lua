ATTRIBUTE.name = "Weapons"
ATTRIBUTE.description = "."
ATTRIBUTE.category = "Proffesions"