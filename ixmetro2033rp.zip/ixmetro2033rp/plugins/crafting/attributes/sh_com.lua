
ATTRIBUTE.name = "Computers"
ATTRIBUTE.description = "."
ATTRIBUTE.category = "Proffesions"