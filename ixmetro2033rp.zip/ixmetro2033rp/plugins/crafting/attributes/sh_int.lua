ATTRIBUTE.name = "Intelligence"
ATTRIBUTE.description = "Being intelligent can really save your ass ya know."