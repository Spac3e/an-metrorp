ITEM.name = "Weapon Repair Kit"
ITEM.durability = 25
ITEM.quantity = 4
ITEM.chance = 48
