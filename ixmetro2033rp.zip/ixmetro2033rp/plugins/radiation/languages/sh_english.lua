LANGUAGE = {
	minorIrradiation = "Minor Radiation Poisoning",
	criticalIrradiation = "Critical Radiation Poisoning",
	deadlyIrradiation = "Deadly Radiation Poisoning",
	addedNewIrradiated = "You've added a new irradiated area.",
	CharSetRadiation1 = "You've set your radiation as %s.",
	CharSetRadiation2 = "You've set %s's radiation as %s.",
	CharSetRadiation3 = "%s have set your radiation as %s.",
	irradiatedAreaCommand = "Run the command again at a different position to set a maximum point.",
	irradiatedAreaRemoved = "Irradiated area is removed.",
	irradiatedAreaBeArea = "You need to be in irradiated area to remove.",
}