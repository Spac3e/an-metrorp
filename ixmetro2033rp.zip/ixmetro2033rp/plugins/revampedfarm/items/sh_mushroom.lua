ITEM.name = "Mushroom"
ITEM.description = "A tasty edible mushroom."
ITEM.model = "models/devcon/mrp/props/mushroom_2.mdl"
ITEM.height = 1
ITEM.width = 1
ITEM.category = "Farming"
ITEM.uniqueID = "mushroom"

ITEM.price = 3

