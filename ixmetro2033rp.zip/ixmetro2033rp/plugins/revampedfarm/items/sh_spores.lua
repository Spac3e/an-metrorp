ITEM.name = "Mushroom Spores"
ITEM.description = "These seeds can be used to grow mushrooms"
ITEM.model = "models/props_lab/box01b.mdl"
ITEM.uniqueID = "mushroom_seeds"
ITEM.width = 1
ITEM.height = 1
ITEM.category = "Farming"
ITEM.data = { producing2 = 0, growth = 0 }
ITEM.color = Color(50, 255, 50)
