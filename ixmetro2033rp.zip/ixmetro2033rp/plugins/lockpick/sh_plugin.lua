local pl = PLUGIN

pl.name = "Lockpick Item"
pl.description = "Adds a lock-picking item."
pl.author = "Nforce"