PLUGIN.name = "Hunting"
PLUGIN.author = "Anon."
PLUGIN.description = "A hunting system that lets you skin animals"

ix.util.Include("sv_plugin.lua")