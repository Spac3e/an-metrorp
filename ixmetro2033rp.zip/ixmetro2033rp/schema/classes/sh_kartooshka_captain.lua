CLASS.name = "KPF Captain"
CLASS.faction = FACTION_KPF
CLASS.isDefault = false
CLASS_KPF = CLASS.index