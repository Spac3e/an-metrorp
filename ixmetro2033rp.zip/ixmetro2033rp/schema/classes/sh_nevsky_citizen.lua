CLASS.name = "Nevsky Prospekt Citizen"
CLASS.faction = FACTION_NEVSKY
CLASS.isDefault = true
CLASS_METRO = CLASS.index