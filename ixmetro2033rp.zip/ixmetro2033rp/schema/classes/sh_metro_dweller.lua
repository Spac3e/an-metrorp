CLASS.name = "Metro Dweller"
CLASS.faction = FACTION_METRO
CLASS.isDefault = true
CLASS_METRO = CLASS.index