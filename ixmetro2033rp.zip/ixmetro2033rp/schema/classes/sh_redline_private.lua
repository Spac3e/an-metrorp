CLASS.name = "Redline Recruit"
CLASS.faction = FACTION_RED
CLASS.isDefault = false
CLASS_RED = CLASS.index