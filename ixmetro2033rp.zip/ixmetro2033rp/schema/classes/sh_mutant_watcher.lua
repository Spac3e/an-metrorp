CLASS.name = "Watcher"
CLASS.faction = FACTION_MUTANT
CLASS.isDefault = false
CLASS_MUTANT = CLASS.index