CLASS.name = "Redline Colonel"
CLASS.faction = FACTION_RED
CLASS.isDefault = false
CLASS_RED = CLASS.index