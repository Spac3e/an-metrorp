CLASS.name = "Redline Captain"
CLASS.faction = FACTION_RED
CLASS.isDefault = false
CLASS_RED = CLASS.index