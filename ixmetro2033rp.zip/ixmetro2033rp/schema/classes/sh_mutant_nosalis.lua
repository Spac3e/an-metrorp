CLASS.name = "Nosalis"
CLASS.faction = FACTION_MUTANT
CLASS.isDefault = true
CLASS_MUTANT = CLASS.index