CLASS.name = "Fourth Reich Captain"
CLASS.faction = FACTION_NAZI
CLASS.isDefault = false
CLASS_NAZI = CLASS.index