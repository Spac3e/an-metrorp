CLASS.name = "KPF Recruit"
CLASS.faction = FACTION_KPF
CLASS.isDefault = true
CLASS_KPF = CLASS.index