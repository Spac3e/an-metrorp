CLASS.name = "Fourth Reich Citizen"
CLASS.faction = FACTION_NAZI
CLASS.isDefault = true
CLASS_NAZI = CLASS.index