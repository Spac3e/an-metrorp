CLASS.name = "KPF Sergeant"
CLASS.faction = FACTION_KPF
CLASS.isDefault = false
CLASS_KPF = CLASS.index