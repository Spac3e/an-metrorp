CLASS.name = "Fourth Reich Recruit"
CLASS.faction = FACTION_NAZI
CLASS.isDefault = false
CLASS_NAZI = CLASS.index