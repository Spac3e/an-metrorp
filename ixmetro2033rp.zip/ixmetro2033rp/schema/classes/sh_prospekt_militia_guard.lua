CLASS.name = "Propsket Militia Guard"
CLASS.faction = FACTION_MILITIA
CLASS.isDefault = true
CLASS_METRO = CLASS.index