CLASS.name = "Redline Citizen"
CLASS.faction = FACTION_RED
CLASS.isDefault = true
CLASS_RED = CLASS.index