CLASS.name = "Bar Tender"
CLASS.faction = FACTION_METRO
CLASS.isDefault = false
CLASS_METRO = CLASS.index