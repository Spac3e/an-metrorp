CLASS.name = "KPF Corporal"
CLASS.faction = FACTION_KPF
CLASS.isDefault = true
CLASS_KPF = CLASS.index