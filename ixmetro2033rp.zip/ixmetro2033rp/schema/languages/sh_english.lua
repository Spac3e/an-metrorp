LANGUAGE = {
	schemaName = "Metro Roleplay",
	tying = "Tying...",
	unTying = "Untying...",
	isTied = "Tied",
	fTiedUp = "You have been tied up.",
	fBeingTied = "You are being tied up.",
	tiedUp = "They have been tied up.",
	beingTied = "They are being tied up.",
	beingUntied = "They are being untied.",
	searchingCorpse = "Searching corpse...",
	radioNotOn = "Your radio isn't on!",
	radioRequired = "You need a radio to do this.",
	radioAlreadyOn = "You already have a radio that is turned on!",
	economy = "Economy",

}
