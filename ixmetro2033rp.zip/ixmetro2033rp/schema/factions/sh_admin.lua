
FACTION.name = "Admin On Duty"
FACTION.description = "Aberration Networks Administration On Duty."
FACTION.color = Color(0, 255, 255, 255)
FACTION.isDefault = false
FACTION.isGloballyRecognized = true

FACTION_ADMIN = FACTION.index
