
FACTION.name = "Kartooshka Police Force"
FACTION.description = "The primary Police Force of Kartooshka."
FACTION.color = Color(255, 200, 100, 255)
FACTION.models = {
		"models/devcon/mrp/act/ranger_2.mdl",
		"models/nikout/metro_ll/spartan1.mdl",
		"models/nikout/metro_ll/spartan1_light.mdl",
		
}
FACTION.isGloballyRecognized = false
FACTION.isDefault = false

FACTION_KPF = FACTION.index
