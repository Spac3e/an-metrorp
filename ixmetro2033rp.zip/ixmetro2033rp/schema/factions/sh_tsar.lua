
FACTION.name = "Tsarist Metro Movement"
FACTION.description = "A Monarchist Faction focusing around restoring the Tsarist Regime."
FACTION.color = Color(150, 125, 100, 255)
FACTION.isDefault = false
FACTION.isGloballyRecognized = false

FACTION_TSAR = FACTION.index
