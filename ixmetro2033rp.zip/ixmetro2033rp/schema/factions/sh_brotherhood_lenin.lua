
FACTION.name = "The Brotherhood of Lenin"
FACTION.description = "A Cult based Neo-Leninist Faction within the Metro."
FACTION.color = Color(255, 0, 0, 255)

FACTION.isDefault = false
FACTION.isGloballyRecognized = false

FACTION_LENIN = FACTION.index
