
FACTION.name = "Metro Monarchist Alliance"
FACTION.description = "A Group of Monarchies allied together."
FACTION.color = Color(107, 194, 130, 255)
FACTION.models = {
	"models/devcon/mrp/act/green_coat.mdl",
	"models/cultist_kun/red_sol4.mdl",
}
FACTION.isDefault = false
FACTION.isGloballyRecognized = false

FACTION_MONARCHIST = FACTION.index
