
FACTION.name = "NazBol"
FACTION.description = "A Neo-Nazi Group within the Metro believing in National Bolshevekism."
FACTION.color = Color(0, 0, 0, 0)
FACTION.pay = 5
FACTION.models = {
	"models/half-dead/metroll/a2b1.mdl",
	"models/half-dead/metroll/a4b1.mdl",
	"models/half-dead/metroll/a5b1.mdl",
	"models/half-dead/metroll/a1b1.mdl",
	"models/half-dead/metroll/f1b1.mdl",
	"models/half-dead/metroll/f2b1.mdl",
	"models/half-dead/metroll/f6b1.mdl",
	"models/ninja/signalvariance/act_middle_revolyucioner_a3.mdl",
	"models/ninja/signalvariance/act_middle_revolyucioner_artyom.mdl",
	"models/ninja/signalvariance/act_middle_revolyucioner_bf4.mdl",
	"models/ninja/signalvariance/act_middle_revolyucioner_hunter.mdl",
	"models/devcon/mrp/act/guard.mdl",
	"models/devcon/mrp/act/reich_enlisted.mdl",
}
FACTION.isDefault = false
FACTION.isGloballyRecognized = false

FACTION_NAZI = FACTION.index
