
FACTION.name = "Game Masters"
FACTION.description = "Aberration Networks GM On Duty"
FACTION.color = Color(0, 255, 255, 255)
FACTION.isDefault = false
FACTION.isGloballyRecognized = true

FACTION_ADMIN = FACTION.index
