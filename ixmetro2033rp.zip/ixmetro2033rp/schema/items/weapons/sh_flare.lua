ITEM.name = "Flare"
ITEM.description = "Industrial-crafted handheld light source. It can be thrown to light up dark areas from far away."
ITEM.model = "models/weapons/yurie_rustalpha/wm-flare.mdl"
ITEM.class = "tfa_rustalpha_flare"
ITEM.weaponCategory = "secondary"
ITEM.width = 1
ITEM.height = 1