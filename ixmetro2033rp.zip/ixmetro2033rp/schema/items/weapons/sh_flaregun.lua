ITEM.name = "Flare Gun"
ITEM.description = "The plastic-like body of the is warped and scratched up. It wasn't kept in the best of condition but it can still shoot flare rounds to illuminate areas if you forgot your flashlight charger. Point up to shoot...unless you're aiming at something else."
ITEM.model = "models/vj_weapons/w_flaregun.mdl"
ITEM.class = "weapon_vj_flaregun"
ITEM.weaponCategory = "secondary"
ITEM.width = 2
ITEM.height = 1