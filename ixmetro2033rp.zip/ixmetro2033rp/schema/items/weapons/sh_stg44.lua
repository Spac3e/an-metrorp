ITEM.name = "STG44"
ITEM.description = "A fully automatic, german assault rifle using 7.92x33mm."
ITEM.model = "models/weapons/w_ins2_stg44t7.mdl"
ITEM.class = "tfa_ins2_doi_stg44_f"
ITEM.weaponCategory = "primary"
ITEM.width = 3
ITEM.height = 2