ITEM.name = "GD Grenade"
ITEM.description = "A Russian made smoke grenade. Toss it near or far and watch as a plume of smoke fills the area. You could also use it as a distraction or to cover your tracks."
ITEM.model = "models/weapons/w_stalker_grenade_gd.mdl"
ITEM.class = "stalker_grenade_gd"
ITEM.weaponCategory = "secondary"
ITEM.width = 1
ITEM.height = 1