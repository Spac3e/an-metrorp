ITEM.name = "Pipe Shotgun"
ITEM.description = "A pipe crafted into a shotgun. Simple enough to defend yourself, but not great for long engagements."
ITEM.model = "models/weapons/yurie_rustalpha/wm-pipeshotgun.mdl"
ITEM.class = "tfa_rustalpha_pipeshotgun"
ITEM.weaponCategory = "primary"
ITEM.width = 3
ITEM.height = 2
ITEM.chance = 27