ITEM.name = "Baseball Bat"
ITEM.description = "A pre-war device with a broken finish, appearing to be splintered through the majority of the wood."
ITEM.model = "models/weapons/w_baseballbat.mdl"
ITEM.class = "weapon_bat_wood"
ITEM.weaponCategory = "melee"
ITEM.width = 2
ITEM.height = 3
ITEM.chance = 17