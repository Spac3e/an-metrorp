ITEM.name = "RGD Grenade"
ITEM.description = "A Russian made grenade. Pull the pin and lob it to the enemy. You now have roughly five seconds to find cover."
ITEM.model = "models/weapons/w_stalker_grenade_rgd.mdl"
ITEM.class = "stalker_grenade_rgd"
ITEM.weaponCategory = "secondary"
ITEM.width = 1
ITEM.height = 1