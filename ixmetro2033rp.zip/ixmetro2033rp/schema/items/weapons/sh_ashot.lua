ITEM.name = "Ashot"
ITEM.description = "A single shot crude shotgun, firing shotgun shells."
ITEM.model = "models/redux/weapons/ashot.mdl"
ITEM.class = "tfa_metro_exo_cumshot"
ITEM.weaponCategory = "primary"
ITEM.width = 2
ITEM.height = 1
ITEM.chance = 29