  
ITEM.name = "MP40"
ITEM.description = "A german submachinegun using 9x19mm."
ITEM.model = "models/vj_weapons/w_mp40.mdl"
ITEM.class = "weapon_mp40_waw"
ITEM.weaponCategory = "primary"
ITEM.width = 3
ITEM.height = 1
ITEM.chance = 1
ITEM.rare = true