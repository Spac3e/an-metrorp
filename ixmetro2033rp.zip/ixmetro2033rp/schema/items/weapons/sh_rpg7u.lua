ITEM.name = "RPG-7u"
ITEM.description = "A large weapon that fires a rocket-propelled-grenade through a mechanism. It is typically an Anti-tank weapon."
ITEM.model = "models/vj_weapons/w_ins_rpg7.mdl"
ITEM.class = "stalker_rpg"
ITEM.weaponCategory = "primary"
ITEM.width = 5
ITEM.height = 3