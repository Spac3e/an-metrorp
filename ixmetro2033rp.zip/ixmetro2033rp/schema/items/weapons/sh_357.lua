ITEM.name = "Revolver"
ITEM.description = "A sidearm utilizing revolver ammunition."
ITEM.model = "models/kali/weapons/metro 2033/revolver.mdl"
ITEM.class = "tfa_metro_exo_revolver"
ITEM.weaponCategory = "sidearm"
ITEM.width = 1
ITEM.height = 1
ITEM.weight = 1.9