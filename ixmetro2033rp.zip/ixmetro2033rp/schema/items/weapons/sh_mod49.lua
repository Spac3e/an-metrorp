ITEM.name = "Mod 49"
ITEM.description = "A Cold War era SMG."
ITEM.model = "models/weapons/w_smg_m90.mdl"
ITEM.class = "weapon_mod49"
ITEM.weaponCategory = "primary"
ITEM.width = 3
ITEM.height = 2