ITEM.name = "Doublet"
ITEM.description = "A rusty double barrel shotgun with a wooden stock. It fires shotgun shells."
ITEM.model = "models/kali/weapons/metro 2033/duplet.mdl"
ITEM.class = "tfa_metro_2_db_shotgun"
ITEM.weaponCategory = "primary"
ITEM.width = 4
ITEM.height = 2
ITEM.chance = 19