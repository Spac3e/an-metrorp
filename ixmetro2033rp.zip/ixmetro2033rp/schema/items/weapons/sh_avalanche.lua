ITEM.name = "SA Avalanche"
ITEM.description = "A suppressed rifle from Ukraine. It utilizes modified rifle rounds."
ITEM.model = "models/weapons/w_stalker_as_val.mdl"
ITEM.class = "stalker_val"
ITEM.weaponCategory = "primary"
ITEM.width = 3
ITEM.height = 2