ITEM.name = "Grenade"
ITEM.description = "A small, green rusted RGD-9 Fragmentation grenade that explodes a few seconds after it is thrown."
ITEM.model = "models/weapons/w_grenade.mdl"
ITEM.class = "stalker_grenade_rgd"
ITEM.weaponCategory = "grenade"
ITEM.width = 1
ITEM.height = 1