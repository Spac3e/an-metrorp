ITEM.name = "Hunting Knife"
ITEM.description = "A short, sharp blade typically used to skin game while hunting. It could also be used against humans proficiently."
ITEM.model = "models/weapons/w_knife_stalker.mdl"
ITEM.class = "stalker_knife"
ITEM.weaponCategory = "melee"
ITEM.width = 1
ITEM.height = 2
ITEM.chance = 43