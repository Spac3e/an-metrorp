ITEM.name = "Scrap Bolt-Action Rifle"
ITEM.description = "A bolt-action rifle made of scrap. An easy ranged rifle to use. This weapon uses sniper rounds."
ITEM.model = "models/weapons/yurie_rustalpha/wm-boltactionrifle.mdl"
ITEM.class = "tfa_rustalpha_bolt_action_rifle"
ITEM.weaponCategory = "primary"
ITEM.width = 2
ITEM.height = 1
ITEM.chance = 12