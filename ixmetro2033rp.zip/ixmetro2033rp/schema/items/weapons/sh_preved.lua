ITEM.name = "Preved AT Rifle"
ITEM.description = "A pre-war anti-material rifle firing 12.7mm rounds."
ITEM.model = "models/redux/weapons/preved.mdl"
ITEM.class = "tfa_metro_heavy_sniper"
ITEM.weaponCategory = "primary"
ITEM.width = 3
ITEM.height = 2