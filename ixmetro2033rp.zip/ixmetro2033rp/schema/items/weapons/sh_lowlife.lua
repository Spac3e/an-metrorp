ITEM.name = "Lowlife"
ITEM.description = "A crude pistol resembling the C96 Mauser. It fires 9x18mm crude."
ITEM.model = "models/kali/weapons/metro 2033/lolife.mdl"
ITEM.class = "tfa_metro_lowlife"
ITEM.weaponCategory = "secondary"
ITEM.width = 2
ITEM.height = 1
ITEM.chance = 34