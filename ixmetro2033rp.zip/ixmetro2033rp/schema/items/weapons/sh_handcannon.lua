ITEM.name = "Hand Cannon"
ITEM.description = "Makeshift weapon utilizing a flintlock system. On close range it is very effective."
ITEM.model = "models/weapons/yurie_rustalpha/wm-handcannon.mdl"
ITEM.class = "tfa_rustalpha_handcannon"
ITEM.weaponCategory = "secondary"
ITEM.width = 1
ITEM.height = 1
ITEM.chance = 27