ITEM.name = "Scrap Revolver"
ITEM.description = "An unusually crafted revolver using .357 rounds. Good enough for personal defense."
ITEM.model = "models/weapons/yurie_rustalpha/wm-revolver.mdl"
ITEM.class = "tfa_rustalpha_revolver"
ITEM.weaponCategory = "secondary"
ITEM.width = 2
ITEM.height = 1
ITEM.chance = 17