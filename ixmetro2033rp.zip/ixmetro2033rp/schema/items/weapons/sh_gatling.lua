ITEM.name = "Minigun"
ITEM.description = "A large, heavy weapon firing rifle rounds at a high fire rate."
ITEM.model = "models/redux/weapons/gatling.mdl"
ITEM.class = "tfa_metro_minigun"
ITEM.weaponCategory = "primary"
ITEM.width = 4
ITEM.height = 3