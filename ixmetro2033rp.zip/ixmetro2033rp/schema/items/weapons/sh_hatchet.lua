ITEM.name = "Hatchet"
ITEM.description = "A chopping tool made with Iron. Similar to the Stone Hatchet, but with more damage and durability."
ITEM.model = "models/weapons/yurie_rustalpha/wm-hatchet.mdl"
ITEM.class = "tfa_rustalpha_hatchet"
ITEM.weaponCategory = "melee"
ITEM.width = 1
ITEM.height = 2
ITEM.chance = 41