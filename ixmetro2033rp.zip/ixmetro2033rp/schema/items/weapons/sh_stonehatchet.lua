ITEM.name = "Stone Hatchet"
ITEM.description = "A sturdy stick with a sharpened stone attached to it. It can be used for breaking something or someone."
ITEM.model = "models/weapons/yurie_rustalpha/wm-stonehatchet.mdl"
ITEM.class = "tfa_rustalpha_stone_hatchet"
ITEM.weaponCategory = "melee"
ITEM.width = 1
ITEM.height = 2
ITEM.chance = 20
