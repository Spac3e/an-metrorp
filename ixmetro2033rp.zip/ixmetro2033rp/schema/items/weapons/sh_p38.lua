ITEM.name = "Walther P-38"
ITEM.description = "An old, german pistol utilizing 9x19mm."
ITEM.model = "models/weapons/w_pist_p38p.mdl"
ITEM.class = "weapon_p38"
ITEM.weaponCategory = "secondary"
ITEM.width = 2
ITEM.height = 1