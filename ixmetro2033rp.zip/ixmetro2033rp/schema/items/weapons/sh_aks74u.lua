ITEM.name = "AKS-74u"
ITEM.description = "Russian assault rifle shortened for airborne operations. Uses modified SMG Rounds."
ITEM.model = "models/weapons/w_stalker_ak74u.mdl"
ITEM.class = "stalker_ak74_u"
ITEM.weaponCategory = "primary"
ITEM.width = 2
ITEM.height = 1