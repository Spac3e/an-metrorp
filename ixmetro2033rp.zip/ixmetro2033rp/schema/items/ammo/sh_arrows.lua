ITEM.name = "Arrows"
ITEM.model = "models/weapons/yurie_rustalpha/worldarrow.mdl"
ITEM.ammo = "tfa_rustalpha_ammo_arrow"
ITEM.ammoAmount = 10
ITEM.description = "A set of wooden arrows with steel spikes, utilizing a mix of rubber + plastic to stabilize it." 