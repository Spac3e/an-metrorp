ITEM.name = "Crude Sniper Ammunition"
ITEM.model = "models/Items/BoxSRounds.mdl"
ITEM.ammo = "tfa_ammo_sniper_rounds"-- type of the ammo
ITEM.ammoAmount = 5 -- amount of the ammo
ITEM.description = "A Box that contains %s of Crude Sniper Ammo"