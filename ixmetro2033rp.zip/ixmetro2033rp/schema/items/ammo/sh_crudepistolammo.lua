ITEM.name = "Crude Pistol Ammunition"
ITEM.model = "models/kek1ch/ammo_9x19_fmj.mdl"
ITEM.ammo = "item_ammo_357"-- type of the ammo
ITEM.ammoAmount = 30 -- amount of the ammo
ITEM.description = "A Box that contains %s of Crude Pistol Ammo"
ITEM.chance = 37