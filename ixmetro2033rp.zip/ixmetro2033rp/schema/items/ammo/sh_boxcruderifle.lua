ITEM.name = "Large Box of Crude Rifle Rounds"
ITEM.model = "models/kek1ch/ammo_pkm.mdl"
ITEM.ammo = "ar2" -- type of the ammo
ITEM.ammoAmount = 100 -- amount of the ammo
ITEM.description = "A large box that contains %s of Crude Rifle Rounds."
ITEM.chance = 10
ITEM.rare = true