ITEM.name = "Crude SMG Ammunition"
ITEM.model = "models/Items/BoxMRounds.mdl"
ITEM.ammo = "tfa_ammo_smg"-- type of the ammo
ITEM.ammoAmount = 15 -- amount of the ammo
ITEM.description = "A Box that contains %s of Crude SMG Ammo"