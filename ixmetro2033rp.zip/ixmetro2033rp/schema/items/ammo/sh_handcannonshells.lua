ITEM.name = "Handcannon Shell"
ITEM.model = "models/weapons/yurie_rustalpha/genericitempickup.mdl"
ITEM.ammo = "tfa_rustalpha_ammo_handmade_shell"
ITEM.ammoAmount = 15
ITEM.description = "A pouch containing 15 handmade shells for the popular Handcannon." 