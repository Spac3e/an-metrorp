ITEM.name = "Box of Crude Rifle Rounds"
ITEM.model = "models/kek1ch/ammo_pkm.mdl"
ITEM.ammo = "ar2" -- type of the ammo
ITEM.ammoAmount = 60 -- amount of the ammo
ITEM.description = "A Cartridge that contains %s of Crude Rifle Rounds"
ITEM.chance = 31
ITEM.rare = true