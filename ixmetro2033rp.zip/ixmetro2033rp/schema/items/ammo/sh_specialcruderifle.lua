ITEM.name = "Special Crude Rifle Ammo"
ITEM.model = "models/Items/BoxMRounds.mdl"
ITEM.ammo = "stalker_ammo_rifle" -- type of the ammo
ITEM.ammoAmount = 30 -- amount of the ammo
ITEM.description = "A Cartridge that contains %s of Special Rifle Ammo that can be used in the AKS-74, Obokan, SA Avalanche."

