ITEM.name = "Small Box of Crude Rifle Ammunition"
ITEM.model = "models/kek1ch/ammo_762x39_fmj.mdl"
ITEM.ammo = "ar2"-- type of the ammo
ITEM.ammoAmount = 30 -- amount of the ammo
ITEM.description = "A Box that contains %s of Crude Rifle Ammo"
ITEM.chance = 31