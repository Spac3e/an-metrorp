ITEM.name = "Valve Rounds"
ITEM.description = "A box containing %s of post-war munitions intended for the Valve Bolt-Action Rifle. "
ITEM.model = "models/kek1ch/ammo_762x54_7h14.mdl"
ITEM.ammo = "tfa_ammo_winchester" -- type of the ammo
ITEM.ammoAmount = 20 -- amount of the ammo
ITEM.chance = 17