ITEM.name = "Crude Heavy Pistol Ammunition"
ITEM.model = "models/kek1ch/ammo.mdl"
ITEM.ammo = "tfa_ammo_pistol"-- type of the ammo
ITEM.ammoAmount = 20 -- amount of the ammo
ITEM.description = "A Box that contains %s of Crude Pistol Ammo"
ITEM.chance = 37