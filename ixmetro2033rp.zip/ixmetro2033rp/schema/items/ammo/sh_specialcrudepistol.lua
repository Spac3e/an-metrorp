ITEM.name = "Special Crude Pistol Munitions"
ITEM.model = "models/items/boxsrounds.mdl"
ITEM.ammo = "stalker_ammo_pistol"
ITEM.ammoAmount = 50
ITEM.description = "Cartrides containing pistol rounds for the Kora 919 and the PMM." 