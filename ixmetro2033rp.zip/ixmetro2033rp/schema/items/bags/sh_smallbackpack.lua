ITEM.name = "Small Backpack"
ITEM.description = "A small backpack capable of holding things."
ITEM.model = Model("models/fallout 3/backpack_2.mdl")
ITEM.invWidth = 4
ITEM.invHeight = 3
ITEM.weight = 10
ITEM.chance = 31