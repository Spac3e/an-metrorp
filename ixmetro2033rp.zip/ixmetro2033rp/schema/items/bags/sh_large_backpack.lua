ITEM.name = "Large Backpack"
ITEM.description = "A large bulky backpack with a bedroll attached."
ITEM.model = Model("models/devcon/mrp/props/backpack.mdl")
ITEM.invWidth = 5
ITEM.invHeight = 4
ITEM.weight = 15
ITEM.chance = 29
ITEM.rare = true